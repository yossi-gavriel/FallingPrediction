# AGY engineering review (Phase 2 architecture, before implementation)

| Item | Value |
|---|---|
| Reviewer | AGY = Antigravity CLI (`agy -p`), model `gemini-3.1-pro-high` passed with `--model` for this call only (the CLI's configured default, GPT-OSS 120B, was not changed) |
| Date | 2026-09-29 |
| Tokens (reported by the CLI) | input 16,863 · output 4,826 · thinking 2,612 · total 21,689; 1 turn, 47 s |
| Input | `reviews/briefs/AGY_BRIEF.md` (2,131 words: context paragraph + `planning/ARCHITECTURE_PHASE2.md` draft 1 + 9 questions); run from an empty folder; no repository, no data |
| Consultations so far | 1 of the planned maximum of 2 (the second only if the architecture changes substantially) |

How each recommendation was resolved is recorded in `reviews/REVIEW_DECISIONS.md`. The review text below is verbatim.

---

Here is the engineering review of the Phase 2 architecture draft. 

### 1. Checkpoint/resume architecture
* **Failure scenario:** A power loss occurs *after* `ITEM_COMPLETE.json` is written inside the `.tmp-<item>` directory, but *before* the directory rename (`.tmp-<item>` → `items/<item>`) is committed to the NTFS Master File Table (MFT). On resume, the system sees a `.tmp-<item>` directory containing a valid marker. If the resume logic blindly moves it to `_incomplete/`, it wastes a durable, completed item. If it accepts it because the marker is valid, it violates the contract that valid items only exist at `items/<item>`. Furthermore, directory renames on Windows are not strictly atomic regarding their contents without explicit flushing.
* **Fix:** Write `ITEM_COMPLETE.json` outside the item directory (e.g., `items/<item>.marker.json.tmp`) *after* the directory rename is complete. Flush the file, then atomically rename it to `items/<item>.marker.json`. The resume protocol must dictate that an item is complete *if and only if* `items/<item>.marker.json` exists; if it doesn't, any existing `<item>` or `.tmp-<item>` directory is moved to `_incomplete/`.

### 2. Artifact immutability
* **Failure scenario:** Windows OneDrive syncs the `--out` folder, or the user opens an aggregate CSV in Excel while the run is active. OneDrive puts opportunistic locks on files during upload; Excel places aggressive read/write locks and can silently alter line endings or strip trailing zeroes if it auto-saves. This will cause `os.replace` to fail with a `PermissionError` (sharing violation) or alter the artifact hashes mid-run.
* **Fix:** 1) Preflight (S00) must verify that the `--out` directory is *not* inside a OneDrive/Dropbox synced path. 2) Apply a robust retry loop (with exponential backoff) for *all* file reads and directory renames to survive AV/OneDrive locks. 3) Apply OS-level read-only permissions (`stat.S_IREAD`) to all files in `artifacts/`, `stages/`, and `protected/` immediately after their hashes are written.

### 3. Experiment registry
* **Failure scenario:** `xgb_trials.jsonl` (the ledger) and `xgb_optuna.sqlite` are redundant sources of truth. If the system crashes, Optuna's SQLite DB might contain an uncommitted or corrupted transaction that diverges from the append-only JSONL ledger. An external reviewer cannot audit SQLite easily. Additionally, tracing code versions across a resumed run is incomplete if the code changes mid-run but isn't explicitly mapped to specific items.
* **Fix:** Declare `xgb_trials.jsonl` as the *absolute* source of truth for XGBoost. If the SQLite DB is unreadable or out of sync on resume, delete it entirely and rebuild it from the JSONL. Expand `RESUME_AUDIT.json` to record the exact Git commit/code hash active at *every* stage and item start, not just the fact that `--accept-code-change` was used. 

### 4. Crash recovery (Windows OS semantics)
* **Failure scenario:** You use `FlushFileBuffers` on the file, then `MoveFileEx`. However, `MoveFileEx` for directories on NTFS does not guarantee that the metadata update is synchronously flushed to the disk platter immediately. A hard crash right after renaming a directory might result in the directory disappearing or becoming corrupted. For partial writes, a crash mid-write of a parquet file leaves a truncated file in `.tmp-<item>` that pandas/pyarrow will choke on if parsed.
* **Fix:** On resume, the `_incomplete/` handler must *move* `.tmp-*` directories without ever attempting to open or read the files inside them. For SQLite, enforce `PRAGMA synchronous = FULL` and `PRAGMA journal_mode = WAL`. To ensure directory rename safety, use Windows `FILE_FLAG_WRITE_THROUGH` when creating critical files, and rely entirely on the presence of the hash-verified JSON marker (as fixed in Q1) to determine if a directory survived intact.

### 5. Deterministic/reproducible execution
* **Failure scenario:** scikit-learn and numpy rely on underlying BLAS/LAPACK libraries (OpenBLAS or MKL). By default, these dynamically allocate thread counts based on available CPU cores at runtime. If a run is resumed while the machine has a different CPU load (or different available cores due to thermal throttling), floating-point summations in LASSO/EN inner loops will occur in a different order, breaking bit-reproducibility across resumes. 
* **Fix:** Pin BLAS threads to 1. In S00 (Preflight), before `numpy` is imported, assert that `OMP_NUM_THREADS=1`, `OPENBLAS_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, and `VECLIB_MAXIMUM_THREADS=1` are set in the environment. Let XGBoost handle multi-threading via explicitly pinning `nthread` in `PHASE2_PLAN.json`. Record these environment variables in the plan.

### 6. Optuna/XGBoost persistent state
* **Failure scenario:** You mention marking a stale-RUNNING trial as FAIL and re-enqueuing its parameters. Optuna's `TPESampler` state is stateful and sequence-dependent. If you mark a trial as FAIL, TPE ignores it, but if you `enqueue_trial` with the exact parameters again, the sampler's RNG will have advanced differently than it would have during an uninterrupted run, breaking mathematical determinism.
* **Fix:** Do not mark stale RUNNING trials as FAIL. Instead, on resume, physically delete the stale RUNNING trial from the SQLite database (or let it roll back if it was an uncommitted transaction) so Optuna has no memory of it. Then, re-seed the sampler exactly as you do for a fresh trial, ensuring the sequence of `ask()` calls remains perfectly deterministic.

### 7. Efficient compute scheduling
* **Failure scenario:** Attempting process-level parallelism (e.g., `joblib` for outer CV folds) drastically complicates the resume protocol. Multiple worker processes attempting to write to `RUN_STATE.json`, logs, or creating `.tmp` directories on Windows will result in race conditions, sharing violations, and corrupted markers. 
* **Fix:** Process items strictly sequentially. Rely entirely on underlying library multi-threading (XGBoost `nthread=8`, or `n_jobs=8` for scikit-learn grid searches *within* a single item) for compute efficiency. Order the stages so that the primary `BASELINE_15` configuration goes through S06-S12 completely before challenging configurations are tested, ensuring the most valuable data is secured first in case of catastrophic hardware failure.

### 8. Share-package design
* **Failure scenario:** Tracebacks written to `logs/events.jsonl` or S12 TreeSHAP plot metadata may leak the Windows username (e.g., `C:\Users\JohnDoe\work\`). Additionally, if TreeSHAP generates beeswarm or scatter plots for S12, those images inherently plot individual patient data points, which violates the rule that nothing row-level may leave the PC.
* **Fix:** 1) Restrict S12 EXPLAIN figures to global feature importance (bar plots) only; explicitly forbid beeswarm/dependence plots. 2) The S16 privacy scanner must utilize regex to redact all local file paths (e.g., replacing `C:\Users\*\` with `<REDACTED_PATH>`) and MAC addresses from all text, JSON, and markdown files before they are zipped into `share/`. Build `share/` inside a `.tmp-share/` directory, scan it, and only rename it to `share/` if the scan passes zero-violations.

### 9. Abrupt machine shutdown recovery
**Residual risks and mitigations (Ranked):**

1. **Risk:** **0-byte or corrupted JSON markers due to MFT delayed flush.** (Power is lost after file handle closes but before disk controller writes data).
   * **Mitigation:** The resume protocol must catch `json.JSONDecodeError` on *any* marker or ledger file. If a stage/item marker is corrupted, it is treated as missing (item fails validation) and recomputed.
2. **Risk:** **SQLite DB corruption.** (WAL file is orphaned or header is mangled).
   * **Mitigation:** Catch `sqlite3.DatabaseError` on startup. If caught, delete `xgb_optuna.sqlite` and `xgb_optuna.sqlite-wal` and recreate them by replaying the fsync'd `xgb_trials.jsonl`.
3. **Risk:** **Silent RAM/CPU bit flips.** (Long compute on non-ECC RAM Windows PCs can introduce silent mathematical errors that get durably written to parquet).
   * **Mitigation:** Add a quick "known-answer test" in S00 Preflight (e.g., invert a specific large matrix and check the checksum) to verify basic system stability before trusting the hardware for a multi-hour run.
4. **Risk:** **Partial append to JSONL ledgers.** (A crash leaves a half-written JSON string at the end of `logs/events.jsonl` or `xgb_trials.jsonl`).
   * **Mitigation:** On resume, read JSONL files line-by-line. If the final line fails JSON parsing, silently truncate the file to the last valid newline.
5. **Risk:** **Antivirus quarantine mid-write.** (AV flags a newly written `.tmp` binary file as suspicious and locks/quarantines it, causing the run to crash and the file to vanish).
   * **Mitigation:** Preflight must aggressively check that the `--out` folder is excluded from Windows Defender/AV via a diagnostic check (e.g., writing a dummy executable file and checking if it's instantly locked), or failing that, explicitly warn the user and require an `--accept-av-risk` flag.
